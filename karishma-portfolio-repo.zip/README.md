# Karishma Pal - Portfolio

A personal portfolio website built with React and Vite. It shows my projects, experience, skills, achievements and education, with scroll animations and a navy blue theme.

## Features

- Intro section with a circular photo and contact icons
- Projects, experience timeline, skills, achievements and education
- Scroll animations that switch off for people who prefer reduced motion
- Responsive layout for phones, tablets and computers
- Downloadable resume

## Run locally

1. Install Node.js 18 or newer from https://nodejs.org
2. In this folder run:

   ```
   npm install
   npm run dev
   ```

3. Open the address shown in the terminal (usually http://localhost:5173).

## Edit the content

All text, links, projects and skills are in `src/data.js`.
The photo is `public/photo.jpg` and the resume is `public/Karishma_Pal_Resume.pdf`.

## Build for production

```
npm run build
```

The finished site is created in the `dist` folder.

## Tech

React 18, Vite 5, plain CSS.
